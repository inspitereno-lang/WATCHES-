import mongoose from 'mongoose';

const productSchema = new mongoose.Schema(
  {
    id: {
      type: Number,
      required: true,
      unique: true,
      index: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    brand: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    audience: {
      type: String,
      enum: ['Womens', 'Mens', 'Ladies', 'Gents'],
      required: true,
      default: 'Mens',
      index: true,
    },
    factory: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    model: {
      type: String,
      default: '',
    },
    reference: {
      type: String,
      default: '',
    },
    material: {
      type: String,
      default: '',
    },
    size: {
      type: String,
      default: '',
    },
    caliber: {
      type: String,
      default: '',
    },
    warranty: {
      type: String,
      default: '2-Year Service Warranty',
    },
    priceUSD: {
      type: String,
      required: true,
    },
    priceAED: {
      type: String,
      required: true,
    },
    url: {
      type: String,
    },
    image: {
      type: String,
      required: true,
    },
    thumbnail: {
      type: String,
      default: '',
    },
    images: {
      type: [String],
      default: [],
    },
    movement: {
      type: String,
      required: true,
    },
    casing: {
      type: String,
      required: true,
    },
    bezel: {
      type: String,
      required: true,
    },
    glass: {
      type: String,
      required: true,
    },
    waterResistance: {
      type: String,
      required: true,
      default: '50m waterproof vacuum tested',
    },
    description: {
      type: String,
      required: true,
    },
    features: {
      type: [String],
      default: [],
    },
    inStock: {
      type: Boolean,
      required: true,
      default: true,
    },
    isVisible: {
      type: Boolean,
      required: true,
      default: true,
      index: true,
    },
    // Arabic Translations
    nameAr: { type: String, default: '' },
    brandAr: { type: String, default: '' },
    modelAr: { type: String, default: '' },
    materialAr: { type: String, default: '' },
    movementAr: { type: String, default: '' },
    casingAr: { type: String, default: '' },
    bezelAr: { type: String, default: '' },
    glassAr: { type: String, default: '' },
    waterResistanceAr: { type: String, default: '' },
    descriptionAr: { type: String, default: '' },
    featuresAr: { type: [String], default: [] },
    warrantyAr: { type: String, default: '' },
  },
  {
    timestamps: true,
  }
);

productSchema.index({ name: 'text', factory: 'text', brand: 'text', audience: 'text' });

export const Product = mongoose.model('Product', productSchema);
export default Product;
